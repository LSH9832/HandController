sudo apt install python-pip python3-pip
pip3 install --upgrade pip
pip install -r requirements.txt