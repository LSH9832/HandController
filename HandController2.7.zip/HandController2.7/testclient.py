from HandController import Data, WEB
import time

my_remote_data = Data(
    source=WEB,
    host="10.31.203.6",
    port=10086,
    user="admin",
    pwd="admin"
)

while True:
    my_remote_data.update()
    print(my_remote_data.BUTTON.EMERGENCY_STOP,
          my_remote_data.STICK.LEFT.UP_DOWN,
          my_remote_data.STICK.RIGHT.LEFT_RIGHT)
    # time.sleep(0.1)
