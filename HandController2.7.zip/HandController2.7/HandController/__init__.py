from .data import Data
from .data import LOCAL, WEB
import sys
if sys.version > (3, 0):
    from server import run_server


__version__ = "0.0.2"
